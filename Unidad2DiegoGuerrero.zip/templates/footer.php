<footer class="footer">
    <div class="container">
        <p>Contacto: info@almidonadas.com | Tel: 123-456-7890</p>
        <p>© 2024 Almidonadas - Todos los derechos reservados.</p>
    </div>
</footer>