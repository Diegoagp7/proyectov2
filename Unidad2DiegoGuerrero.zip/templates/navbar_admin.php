<nav class="navbar">
    <div class="container">
        <a href="/almidonadas/admin/index.php" class="logo">Almidonadas</a>
        <ul class="nav-links">
            <li><a href="/almidonadas1/includes/logout.php">Cerrar Sesión</a></li>
        </ul>
    </div>
</nav>