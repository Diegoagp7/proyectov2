<nav class="navbar">
    <div class="container">
        <a href="/almidonadas/cliente/index.php" class="logo">Almidonadas</a>
        <ul class="nav-links">
            <li><a href="#">Iniciar sesion</a></li>
            <li><a href="#">Registrarse</a></li>
        </ul>
    </div>
</nav>