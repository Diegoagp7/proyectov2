<div class="whatsapp-icon">
    <a href="https://wa.me/1234567890" target="_blank">
        <i class="fa-brands fa-whatsapp"></i>
    </a>
</div>